#!/usr/bin/env python3
"""Spotify downloader for Shelf.

Output layout matches what Shelf expects:
  Music/Artist Name/Album Name/01 - Song Title.m4a
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def ensure_deps() -> None:
    """Quietly upgrade the tools we need."""
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "yt-dlp", "spotdl", "--quiet"],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        pass


def download(url: str, music_root: Path, threads: int = 4) -> subprocess.CompletedProcess:
    """Download a Spotify URL into music_root using the Shelf-friendly layout."""
    music_root = Path(music_root).expanduser().resolve()
    music_root.mkdir(parents=True, exist_ok=True)

    output_template = str(
        music_root / "{artists}/{album}/{track-number} - {title}.{output-ext}"
    )

    cmd = [
        sys.executable, "-m", "spotdl", "download", url,
        "--output", output_template,
        "--format", "m4a",
        "--bitrate", "320k",
        "--threads", str(threads),
        "--lyrics", "none",
    ]
    return subprocess.run(cmd, check=False)


def main() -> None:
    ensure_deps()
    url = input("Paste Spotify playlist / album / track URL: ").strip()
    if not url:
        print("No URL given.")
        return
    music = Path.home() / "Music"
    print(f"Downloading into {music} …")
    result = download(url, music)
    print("Done." if result.returncode == 0 else f"Finished with code {result.returncode}")


if __name__ == "__main__":
    main()
